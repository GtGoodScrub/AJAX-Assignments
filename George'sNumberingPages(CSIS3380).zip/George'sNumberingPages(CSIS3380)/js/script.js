/*George's Page numbering system*/
/*Got help from Dad*/

//this is how to get an array & set it as a global variable
var items;

//# of pages containing whatever amount of contacts & its remainders
var totalPages, remainder;

//func. to hide all contacts
function setUpPage() {
  items = document.getElementsByTagName("LI");
  remainder = items.length % 10;
  totalPages = Math.ceil(items.length / 10);

  //show 1st page
  myPage(0);
}


//Func. to take page # & display contacts
function myPage(pageNumber) {
    
    var pageSize = 10;
    var firstIndex = pageSize * pageNumber;

  //loop to hide all contacts
  for (var i = 0; i < items.length; i++) {
    showContact(items[i], false);
  }

  //shortcut w/o if statement
  //var isLastPAge = pageNumber == totalPages - 1;
  var isLastPage = false;
  
  if (pageNumber == totalPages - 1) {
    isLastPage = true;
  }

  var length = 10;

  if (isLastPage && remainder > 0) {
    length = remainder;
  }

    //this is to display all contacts within a given page
    for (var i = 0; i < length; i++) {
        var index = firstIndex + i;
        var contact = items[index];
        showContact(contact, true);
    }

    createButtons();
}


//func. to show/hide contact (Part of this code was borrowed from w3schools)
function showContact(x, show) {
    if (show == true) {
      //show contact
      x.style.display = "block";
    } else {
      //hide contact
      x.style.display = "none";
    } 
}


//func. to create buttons
function createButtons() {
  //assign empty string
  var innerHTML = "";

  //loop to create buttons according to page #
  for (var i = 0; i < totalPages; i++) {
    var li = '<li><a href="javascript: myPage(' + i + ')">' + i + '</a></li>';
    innerHTML += li;
    //console.log(li);
  }

  //statement add buttons
  document.getElementById("buttons").innerHTML = innerHTML;
}
